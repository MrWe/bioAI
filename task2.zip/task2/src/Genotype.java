import java.util.ArrayList;

public class Genotype {

    ArrayList<Gene> genes;

    public Genotype(ArrayList<Gene> genes) {
        this.genes = genes;
    }
}
